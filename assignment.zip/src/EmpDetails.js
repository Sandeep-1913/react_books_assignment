function EmpDetails(props) {
  return (
    <div>
      <p>Name:{props.empdetails.name}</p>
      <p>Skills:{props.empdetails.skills}</p>
      <p>Company:{props.empdetails.company}</p>
    </div>
  );
}

export default EmpDetails;
