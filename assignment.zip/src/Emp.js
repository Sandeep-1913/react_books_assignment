import EmpDetails from "./EmpDetails";

function Emp(props) {
  return (
    <div>
      <p className="id">Id: {props.employee.id}</p>
      <EmpDetails empdetails={props.employee} />
    </div>
  );
}

export default Emp;
