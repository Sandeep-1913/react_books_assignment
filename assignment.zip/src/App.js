import "./index.css";
import EmpData from "./EmpData";
import Emp from "./Emp";
import { useState } from "react";
function App() {
  const [employee, setEmployee] = useState(EmpData);

  return (
    <div className="box">
      <h3>The employee data is:</h3>
      <Emp employee={employee} />
    </div>
  );
}

export default App;
