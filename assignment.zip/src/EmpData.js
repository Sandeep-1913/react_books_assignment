const EmpData = {
  id: 2088330,
  name: "Sandeep",
  skills: "ReactJS",
  company: "Cognizant",
};

export default EmpData;
